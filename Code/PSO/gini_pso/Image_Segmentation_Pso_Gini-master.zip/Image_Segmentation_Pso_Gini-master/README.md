# Image_Segmentation_Pso_Gini
a Python project using openCV to segment grayScale images using Partical swarm optimisation (PSO) and Gini-Entropy as an objective function
